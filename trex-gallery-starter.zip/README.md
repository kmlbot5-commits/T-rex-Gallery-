# Trex Gallery 🦖

Website starter for a public image gallery with a private admin area.

## Structure
- `public/index.html` — public gallery
- `public/admin.html` — admin UI
- `public/style.css` — design
- `public/app.js` — public gallery logic
- `public/admin.js` — admin UI starter

## Important
The included login/upload is a UI demo only. Do NOT publish it as a real secure admin system.
For the real version, use Firebase Authentication + Firebase Storage/Firestore (or another backend) so visitors can view/download only while only your authenticated admin can upload/delete.

## Next step
Add your Firebase project configuration and security rules, then deploy.
